package br.edu.ifsp.spo.lp2a4.Comente.sobre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComenteSobreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComenteSobreApplication.class, args);
	}

}
